#include "sc-agents-common/utils/CommonUtils.hpp"
#include "sc-agents-common/utils/IteratorUtils.hpp"
#include <string>
#include <iostream>
#include <vector>

#include "SchoolSearchAgent.hpp"
#include "keynodes/keynodes.hpp"

using namespace std;
using namespace utils;

namespace SchoolSearchAgentModule
{

ScResult SchoolSearchAgent::DoProgram(ScEventAfterGenerateOutgoingArc<ScType::ConstPermPosArc> const & event, ScAction & action)
{
  if (!event.GetArc().IsValid())
    return action.FinishUnsuccessfully();

  SC_AGENT_LOG_INFO("begin");
  ScAddr actionNode = ms_context->GetArcTargetElement(event.GetArc());

  ScAddr school = IteratorUtils::getAnyByOutRelation(&m_context, actionNode, ScKeynodes::rrel_1);

  if (!school.IsValid())
  {
    SC_AGENT_LOG_ERROR("First parameter isn't valid.");
//todo(codegen-removal): replace AgentUtils:: usage
    AgentUtils::finishAgentWork(&m_context, actionNode, false);
    return action.FinishUnsuccessfully();
  }

  ScAddr answer = ms_context->GenerateNode(ScType::ConstNodeStructure);

  ScIterator5Ptr it1 = ms_context->CreateIterator5(
      ScType::Unknown, ScType::ConstCommonArc, school, ScType::ConstPermPosArc, Keynodes::nrel_school_number);
  ScAddr school1;
  ScAddr schoolResult;
  if (it1->Next())
  {
    school = it1->Get(0);
    ScIterator5Ptr it2 = ms_context->CreateIterator5(
        school, ScType::ConstCommonArc, ScType::Unknown, ScType::ConstPermPosArc, Keynodes::nrel_search_area);
    if (it2->Next())
    {
      ms_context->GenerateConnector(ScType::ConstPermPosArc, answer, schoolResult);
    }
    else
    {
      SC_AGENT_LOG_ERROR("There is no such school");
    }
  }

  ScAddr edgeToAnswer = ms_context->GenerateConnector(ScType::ConstCommonArc, actionNode, answer);
  ms_context->GenerateConnector(ScType::ConstPermPosArc, ScKeynodes::nrel_answer, edgeToAnswer);

//todo(codegen-removal): replace AgentUtils:: usage
  AgentUtils::finishAgentWork(ms_context.get(), actionNode);
  SC_AGENT_LOG_INFO("end");
  return action.FinishSuccessfully();
}

ScAddr SchoolSearchAgent::GetActionClass() const
{
//todo(codegen-removal): replace action with your action class
  return ScKeynodes::action;
}

ScAddr SchoolSearchAgent::GetEventSubscriptionElement() const
{
  return Keynodes::action_schoolByNumberSearch;
}

}  // namespace SchoolSearchAgentModule
