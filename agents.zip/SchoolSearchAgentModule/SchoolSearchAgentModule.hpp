#pragma once
#include "sc-memory/sc_memory.hpp"
#include "sc-memory/sc_module.hpp"

#include "keynodes/keynodes.hpp"
#include "agents/SchoolSearchAgent.hpp"

namespace SchoolSearchAgentModule
{

class SchoolSearchAgentModule : public ScModule
{
  };
}  // namespace SchoolSearchAgentModule
