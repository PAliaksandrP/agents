#pragma once

#include "sc-memory/sc_module.hpp"

namespace soatoClassificationModule
{

class SoatoClassificationModule : public ScModule
{
  };

}  // namespace soatoClassificationModule
