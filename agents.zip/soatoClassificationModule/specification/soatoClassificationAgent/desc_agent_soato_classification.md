### Agent of search banks by type

#### Work example

**Example:**

**Input:**

**Output:**