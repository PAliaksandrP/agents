/*
 * This source file is part of an OSTIS project. For the latest info, see http://ostis.net
 * Distributed under the MIT License
 * (See accompanying file COPYING.MIT or copy at http://opensource.org/licenses/MIT)
 */

#include "MuseumsRegionSearchModule.hpp"
namespace MuseumsRegionSearchModule
{
SC_MODULE_REGISTER(MuseumsRegionSearchModule)
  ->Agent<MuseumsRegionSearch>();

//todo(codegen-removal): if needed override ScModule::Initialize and move all non-keynodes and non-agents code from previous initialization method
/*
{
  if (!Keynodes::InitGlobal())
  {
    return SC_RESULT_ERROR;
  }

  ScMemoryContext ctx(sc_access_lvl_make_min, "MuseumsRegionSearchModule");

  //todo(codegen-removal): Use agentContext.SubscribeAgent<MuseumsRegionSearch> or UnsubscribeAgent; to register and unregister agent
SC_AGENT_REGISTER(MuseumsRegionSearch)

  return SC_RESULT_OK;
}
*/


//todo(codegen-removal): if needed override ScModule::Shutdown and move all non-agents code from previous shutdown method
/*
{
  //todo(codegen-removal): Use agentContext.SubscribeAgent<MuseumsRegionSearch> or UnsubscribeAgent; to register and unregister agent
SC_AGENT_UNREGISTER(MuseumsRegionSearch)

  return SC_RESULT_OK;
}
*/
}  // namespace MuseumsRegionSearchModule
