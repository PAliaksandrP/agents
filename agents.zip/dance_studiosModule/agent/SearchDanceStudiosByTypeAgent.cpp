/*
 * This source file is part of an OSTIS project. For the latest info, see http://ostis.net
 * Distributed under the MIT License
 * (See accompanying file COPYING.MIT or copy at http://opensource.org/licenses/MIT)
 */

#include <sc-agents-common/utils/IteratorUtils.hpp>
#include "keynodes/DanceStudiosKeynodes.hpp"

#include "SearchDanceStudiosByTypeAgent.hpp"

using namespace std;
using namespace utils;
namespace dance_studios
{

ScResult SearchDanceStudiosByTypeAgent::DoProgram(ScEventAfterGenerateOutgoingArc<ScType::ConstPermPosArc> const & event, ScAction & action)
{
  SC_AGENT_LOG_INFO("agent start");

  if (!event.GetArc().IsValid())
  {
    return action.FinishUnsuccessfully();
  }

  std::unique_ptr<DanceStudiosByString> danceStudiosByString = std::make_unique<DanceStudiosByString>();

  ScAddr questionNode = ms_context->GetArcTargetElement(event.GetArc());
  ScAddr answer = danceStudiosByString->findDanceStudiosByString(
      ms_context.get(), questionNode, DanceStudiosKeynodes::concept_type, DanceStudiosKeynodes::nrel_type);

  if (!answer.IsValid())
  {
    return action.FinishUnsuccessfully();
  }

  bool success = ms_context->CheckConnector(
      DanceStudiosKeynodes::concept_success_solution, answer, ScType::ConstPermPosArc);

  ScAddr edgeToAnswer = ms_context->GenerateConnector(ScType::ConstCommonArc, questionNode, answer);
  ms_context->GenerateConnector(ScType::ConstPermPosArc, ScKeynodes::nrel_answer, edgeToAnswer);

//todo(codegen-removal): replace AgentUtils:: usage
  AgentUtils::finishAgentWork((ScMemoryContext *)ms_context.get(), questionNode, success);

  return action.FinishSuccessfully();
}

ScAddr SearchDanceStudiosByTypeAgent::GetActionClass() const
{
//todo(codegen-removal): replace action with your action class
  return ScKeynodes::action;
}

ScAddr SearchDanceStudiosByTypeAgent::GetEventSubscriptionElement() const
{
  return DanceStudiosKeynodes::action_search_dance_studios_by_type;
}
}  // namespace dance_studios
