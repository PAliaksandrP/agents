/*
 * This source file is part of an OSTIS project. For the latest info, see http://ostis.net
 * Distributed under the MIT License
 * (See accompanying file COPYING.MIT or copy at http://opensource.org/licenses/MIT)
 */

#include <sc-agents-common/utils/IteratorUtils.hpp>
#include "keynodes/DanceStudiosKeynodes.hpp"

#include "SearchDanceStudiosByFoundingYearAgent.hpp"

using namespace std;
using namespace utils;
namespace dance_studios
{

ScResult SearchDanceStudiosByFoundingYearAgent::DoProgram(ScActionInitiatedEvent const & event, ScAction & action)
{
  SC_AGENT_LOG_INFO("agent start");

  if (!event.GetArc().IsValid())
  {
    return action.FinishUnsuccessfully();
  }

  std::unique_ptr<DanceStudiosByPropertyInNumericalRangeFinder> danceStudiosByPropertyInNumericalRangeFinder =
      std::make_unique<DanceStudiosByPropertyInNumericalRangeFinder>();

  ScAddr questionNode = ms_context->GetArcTargetElement(event.GetArc());
  ScAddr answer = danceStudiosByPropertyInNumericalRangeFinder->findDanceStudiosByPropertyInNumericalRange(
      ms_context.get(),
      questionNode,
      DanceStudiosKeynodes::concept_year_of_foundation,
      DanceStudiosKeynodes::nrel_year_of_foundation);

  if (!answer.IsValid())
  {
    return action.FinishUnsuccessfully();
  }

  bool success = ms_context->CheckConnector(
      DanceStudiosKeynodes::concept_success_solution, answer, ScType::ConstPermPosArc);

  ScAddr edgeToAnswer = ms_context->GenerateConnector(ScType::ConstCommonArc, questionNode, answer);
  ms_context->GenerateConnector(ScType::ConstPermPosArc, ScKeynodes::nrel_answer, edgeToAnswer);

//todo(codegen-removal): replace AgentUtils:: usage
  AgentUtils::finishAgentWork((ScMemoryContext *)ms_context.get(), questionNode, success);

  return action.FinishSuccessfully();
}

ScAddr SearchDanceStudiosByFoundingYearAgent::GetActionClass() const
{
//todo(codegen-removal): replace action with your action class
  return ScKeynodes::action;
}

}  // namespace dance_studios
