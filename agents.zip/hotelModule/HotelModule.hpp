/*
 * Author Artsiom Salauyou
 */

#pragma once

#include "sc-memory/sc_memory.hpp"
#include "sc-memory/sc_module.hpp"

namespace hotelModule
{
class HotelModule : public ScModule
{
  };
}  // namespace hotelModule
