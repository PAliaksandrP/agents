/*
 * Author Artsiom Salauyou
 */

#include "sc-agents-common/utils/IteratorUtils.hpp"

#include "keynodes/HotelKeynodes.hpp"

#include "GetHotelByMinPricePerNightAgent.hpp"

using namespace hotelModule;

ScResult GetHotelByMinPricePerNightAgent::DoProgram(ScActionInitiatedEvent const & event, ScAction & action)
{
  ScAddr actionAddr = event.GetOtherElement();

  if (checkActionClass(actionAddr) == SC_FALSE)
    return action.FinishSuccessfully();

  SC_AGENT_LOG_DEBUG("started");

  ScAddr inputPriceLink =
      utils::IteratorUtils::getAnyByOutRelation(&m_context, actionAddr, ScKeynodes::rrel_1);

  ScAddrVector minPricesPerNight = getPricesLinks(inputPriceLink);

  ScAddrVector answerVector;
  initFields();

  try
  {
    ScAddr hotel;
    if (!minPricesPerNight.empty())
    {
      for (ScAddr minPricePerNight : minPricesPerNight)
      {
        hotel = hotelSearcher->searchHotelByMinPricePerNight(minPricePerNight);
        if (isHotel(hotel))
          answerVector.push_back(hotel);
      }
    }
    else
      SC_AGENT_LOG_WARNING("No hotels found");
  }
  catch (utils::ScException &)
  {
//todo(codegen-removal): replace AgentUtils:: usage
    utils::AgentUtils::finishAgentWork(&m_context, actionAddr, answerVector, false);
    SC_AGENT_LOG_DEBUG("finished");
    return action.FinishUnsuccessfully();
  }

//todo(codegen-removal): replace AgentUtils:: usage
  utils::AgentUtils::finishAgentWork(&m_context, actionAddr, answerVector, true);
  SC_AGENT_LOG_DEBUG("finished");
  return action.FinishSuccessfully();
}

ScAddr GetHotelByMinPricePerNightAgent::GetActionClass() const
{
//todo(codegen-removal): replace action with your action class
  return ScKeynodes::action;
}


void GetHotelByMinPricePerNightAgent::initFields()
{
  this->hotelSearcher = std::make_unique<HotelSearcher>(&m_context);
}

bool GetHotelByMinPricePerNightAgent::checkActionClass(const ScAddr & actionNode)
{
  return m_context.CheckConnector(
      HotelKeynodes::action_get_hotel_by_min_price_per_night, actionNode, ScType::ConstPermPosArc);
}

ScAddrVector GetHotelByMinPricePerNightAgent::getPricesLinks(const ScAddr & inputLink)
{
  auto minPriceLinkContent = ms_context->GetLinkContent(inputLink);
//todo(codegen-removal): method has signature changed
  ScAddrVector links = ms_context->SearchLinksByContent(minPriceLinkContent);

  ScAddrVector resultVector;
  for (ScAddr link : links)
  {
    if (isPriceLink(link) && link != inputLink)
      resultVector.push_back(link);
  }
  return resultVector;
}

bool GetHotelByMinPricePerNightAgent::isHotel(const ScAddr & hotel)
{
  return ms_context->CheckConnector(HotelKeynodes::concept_hotel, hotel, ScType::ConstPermPosArc) &&
         ms_context->CheckConnector(HotelKeynodes::concept_map_object, hotel, ScType::ConstPermPosArc);
}

bool GetHotelByMinPricePerNightAgent::isPriceLink(const ScAddr & priceLink)
{
  return ms_context->CheckConnector(HotelKeynodes::concept_price, priceLink, ScType::ConstPermPosArc) &&
         ms_context->CheckConnector(HotelKeynodes::concept_usd, priceLink, ScType::ConstPermPosArc);
}
