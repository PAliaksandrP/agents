/*
 * Author Artsiom Salauyou
 */

#pragma once

#include "sc-memory/kpm/sc_agent.hpp"
#include "searcher/HotelSearcher.hpp"

namespace hotelModule
{
class GetHotelByMinPricePerNightAgent : public ScActionInitiatedAgent
{
  public:
  ScAddr GetActionClass() const override;

  ScResult DoProgram(ScActionInitiatedEvent const & event, ScAction & action) override;

  private:
  std::unique_ptr<HotelSearcher> hotelSearcher;

  bool checkActionClass(ScAddr const & actionAddr);

  static bool isHotel(ScAddr const & hotel);

  static bool isPriceLink(ScAddr const & priceLink);

  static ScAddrVector getPricesLinks(ScAddr const & InputLink);

  void initFields();
};
}  // namespace hotelModule
