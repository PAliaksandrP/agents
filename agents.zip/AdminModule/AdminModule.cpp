#include "AdminModule.hpp"

SC_MODULE_REGISTER(AdminModule)
  ->Agent<adminModule::GetAdminBuildingRegion>()
  ->Agent<adminModule::GetAdminBuildingDistrict>();

//todo(codegen-removal): if needed override ScModule::Initialize and move all non-keynodes and non-agents code from previous initialization method
/*
{
  if (!adminModule::AdminKeynodes::InitGlobal())  // AdminModule это название пространства в котором находятся агенты и
                                                  // другие классы которые используются для работы агентов
  {
    return SC_RESULT_ERROR;
  }

  ScMemoryContext ctx(
      sc_access_lvl_make_min,
      "adminModule");  // тут AdminModule может быть любой строкой, но для простоты исползуется название пространства
  //todo(codegen-removal): Use agentContext.SubscribeAgent<adminModule::GetAdminBuildingRegion> or UnsubscribeAgent; to register and unregister agent
SC_AGENT_REGISTER(adminModule::GetAdminBuildingRegion)
  //todo(codegen-removal): Use agentContext.SubscribeAgent<adminModule::GetAdminBuildingDistrict> or UnsubscribeAgent; to register and unregister agent
SC_AGENT_REGISTER(adminModule::GetAdminBuildingDistrict)
  // регистрируем свои агенты, можно сколько угодно агентов зарегистрировать, если этого не сдлеать агент работать не
  // будет, так как не загружен в память.

  return SC_RESULT_OK;
}
*/


//todo(codegen-removal): if needed override ScModule::Shutdown and move all non-agents code from previous shutdown method
/*
{
  //todo(codegen-removal): Use agentContext.SubscribeAgent<adminModule::GetAdminBuildingRegion> or UnsubscribeAgent; to register and unregister agent
SC_AGENT_UNREGISTER(adminModule::GetAdminBuildingRegion)
  //todo(codegen-removal): Use agentContext.SubscribeAgent<adminModule::GetAdminBuildingDistrict> or UnsubscribeAgent; to register and unregister agent
SC_AGENT_UNREGISTER(adminModule::GetAdminBuildingDistrict)
  // по аналогии с регистрацией агентов в памяти, убираем их из памяти, прописать для каждого агента в модуле

  return SC_RESULT_OK;
}
*/

