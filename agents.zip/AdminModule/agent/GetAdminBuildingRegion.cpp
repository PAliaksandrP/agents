#include "sc-agents-common/utils/CommonUtils.hpp"
#include "sc-agents-common/utils/IteratorUtils.hpp"
#include "keynodes/AdminKeynodes.hpp"

#include "GetAdminBuildingRegion.hpp"

using namespace adminModule;
using namespace utils;

ScResult GetAdminBuildingRegion::DoProgram(ScEventAfterGenerateOutgoingArc<ScType::ConstPermPosArc> const & event, ScAction & action)
{
  ScAddr actionNode = m_context.GetArcTargetElement(event.GetArc());

  if (!checkActionClass(actionNode))
  {
    return action.FinishSuccessfully();
  }

  SC_AGENT_LOG_DEBUG("started");

  ScAddr firstParameter =
      IteratorUtils::getAnyByOutRelation(&m_context, actionNode, ScKeynodes::rrel_1);

  if (!firstParameter.IsValid())
  {
    SC_AGENT_LOG_ERROR("First parameter isn't valid.");
//todo(codegen-removal): replace AgentUtils:: usage
    finishAgentWork(&m_context, actionNode, false);
    return action.FinishUnsuccessfully();
  }

  ScAddr answerNode = m_context.GenerateNode(ScType::ConstNodeStructure);
  ScAddr district;

  ScIterator5Ptr iterator5 = m_context.CreateIterator5(
      ScType::Unknown,
      ScType::ConstCommonArc,
      firstParameter,
      ScType::ConstPermPosArc,
      AdminKeynodes::nrel_region);
  while (iterator5->Next())
  {
    std::cout << "1 ";

    district = iterator5->Get(0);
    ScAddr building;

    ScIterator5Ptr it5 = m_context.CreateIterator5(
        ScType::Unknown,
        ScType::ConstCommonArc,
        district,
        ScType::ConstPermPosArc,
        AdminKeynodes::nrel_search_area);

    while (it5->Next())
    {
      std::cout << "2 ";
      building = it5->Get(0);

      if (m_context.CheckConnector(AdminKeynodes::concept_admin_building, building, ScType::ConstPermPosArc))
        m_context.GenerateConnector(ScType::ConstPermPosArc, answerNode, building);
    }
  }

  ScAddr edgeToAnswer = ms_context->GenerateConnector(ScType::ConstCommonArc, actionNode, answerNode);
  ms_context->GenerateConnector(ScType::ConstPermPosArc, ScKeynodes::nrel_answer, edgeToAnswer);

//todo(codegen-removal): replace AgentUtils:: usage
  finishAgentWork(&m_context, actionNode, true);
  SC_AGENT_LOG_DEBUG("finished");
  return action.FinishSuccessfully();
}

ScAddr GetAdminBuildingRegion::GetActionClass() const
{
//todo(codegen-removal): replace action with your action class
  return ScKeynodes::action;
}

ScAddr GetAdminBuildingRegion::GetEventSubscriptionElement() const
{
  return AdminKeynodes::action_get_admin_building_region;
}

bool GetAdminBuildingRegion::checkActionClass(const ScAddr & actionNode)
{
  return m_context.CheckConnector(
      AdminKeynodes::action_get_admin_building_region, actionNode, ScType::ConstPermPosArc);
}
