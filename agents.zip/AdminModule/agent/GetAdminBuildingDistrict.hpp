#pragma once

#include "sc-memory/kpm/sc_agent.hpp"

#include "keynodes/AdminKeynodes.hpp"

namespace adminModule
{

class GetAdminBuildingDistrict : public ScAgent<ScEventAfterGenerateOutgoingArc<ScType::ConstPermPosArc>>
{
  public:
  ScAddr GetActionClass() const override;

  ScResult DoProgram(ScEventAfterGenerateOutgoingArc<ScType::ConstPermPosArc> const & event, ScAction & action) override;

  ScAddr GetEventSubscriptionElement() const override;

  private:
  bool checkActionClass(const ScAddr & actionNode);
};

}  // namespace adminModule
