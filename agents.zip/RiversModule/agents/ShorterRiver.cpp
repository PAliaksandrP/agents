/*
 * This source file is part of an OSTIS project. For the latest info, see http://ostis.net
 * Distributed under the MIT License
 * (See accompanying file COPYING.MIT or copy at http://opensource.org/licenses/MIT)
 */

#include "sc-agents-common/utils/CommonUtils.hpp"
#include "sc-agents-common/utils/IteratorUtils.hpp"
#include <string>
#include <iostream>

#include "ShorterRiver.hpp"
#include "keynodes/keynodes.hpp"

using namespace std;
using namespace utils;

namespace RiversModule
{

ScResult ShorterRiver::DoProgram(ScEventAfterGenerateOutgoingArc<ScType::ConstPermPosArc> const & event, ScAction & action)
{
  if (!event.GetArc().IsValid())
    return action.FinishUnsuccessfully();

  SC_AGENT_LOG_INFO("----------LongerRiver begin----------");
  ScAddr actionNode = ms_context->GetArcTargetElement(event.GetArc());

  ScAddr river1 = IteratorUtils::getAnyByOutRelation(&m_context, actionNode, ScKeynodes::rrel_1);

  ScAddr river2 = IteratorUtils::getAnyByOutRelation(&m_context, actionNode, ScKeynodes::rrel_2);
  ScAddr answer = ms_context->GenerateNode(ScType::ConstNodeStructure);

  ScIterator5Ptr it = ms_context->CreateIterator5(
      river1, ScType::ConstCommonArc, ScType::Unknown, ScType::ConstPermPosArc, Keynodes::nrel_length);
  int l1 = 0;
  while (it->Next())
  {
    ScAddr len = it->Get(2);
    std::string str1 = CommonUtils::getIdtf(ms_context.get(), len, Keynodes::nrel_main_idtf);
    l1 = std::atoi(str1.c_str());
  }

  ScIterator5Ptr it1 = ms_context->CreateIterator5(
      river2, ScType::ConstCommonArc, ScType::Unknown, ScType::ConstPermPosArc, Keynodes::nrel_length);
  int l2 = 0;
  while (it1->Next())
  {
    ScAddr len = it1->Get(2);
    std::string str2 = CommonUtils::getIdtf(ms_context.get(), len, Keynodes::nrel_main_idtf);
    l2 = std::atoi(str2.c_str());
  }

  if (l1 < l2)
  {
    ms_context->GenerateConnector(ScType::ConstPermPosArc, answer, river1);
  }
  else
  {
    ms_context->GenerateConnector(ScType::ConstPermPosArc, answer, river2);
  }

  ScAddr edgeToAnswer = ms_context->GenerateConnector(ScType::ConstCommonArc, actionNode, answer);
  ms_context->GenerateConnector(ScType::ConstPermPosArc, ScKeynodes::nrel_answer, edgeToAnswer);

  SC_AGENT_LOG_INFO("----------LongerRiver end----------");
//todo(codegen-removal): replace AgentUtils:: usage
  AgentUtils::finishAgentWork(ms_context.get(), actionNode);
  return action.FinishSuccessfully();
}

ScAddr ShorterRiver::GetActionClass() const
{
//todo(codegen-removal): replace action with your action class
  return ScKeynodes::action;
}

ScAddr ShorterRiver::GetEventSubscriptionElement() const
{
  return Keynodes::question_longerRiver;
}

}  // namespace RiversModule
