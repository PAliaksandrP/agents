/*
 * This source file is part of an OSTIS project. For the latest info, see http://ostis.net
 * Distributed under the MIT License
 * (See accompanying file COPYING.MIT or copy at http://opensource.org/licenses/MIT)
 */

#include "sc-agents-common/utils/CommonUtils.hpp"
#include "sc-agents-common/utils/IteratorUtils.hpp"
#include <string>
#include <iostream>
#include <vector>

#include "TheBiggestBasinInRegion.hpp"
#include "keynodes/keynodes.hpp"

using namespace std;
using namespace utils;

namespace RiversModule
{

ScResult TheBiggestBasinInRegion::DoProgram(ScEventAfterGenerateOutgoingArc<ScType::ConstPermPosArc> const & event, ScAction & action)
{
  if (!event.GetArc().IsValid())
    return action.FinishUnsuccessfully();

  SC_AGENT_LOG_INFO("----------TheBiggestBasinInRegion begin----------");
  ScAddr actionNode = ms_context->GetArcTargetElement(event.GetArc());

  ScAddr region = IteratorUtils::getAnyByOutRelation(&m_context, actionNode, ScKeynodes::rrel_1);

  ScAddr answer = ms_context->GenerateNode(ScType::ConstNodeStructure);

  ScIterator5Ptr it1 = ms_context->CreateIterator5(
      ScType::Unknown, ScType::ConstCommonArc, region, ScType::ConstPermPosArc, Keynodes::nrel_region);
  ScAddr river;
  int number = 0;
  ScAddr riv;
  while (it1->Next())
  {
    river = it1->Get(0);
    ScIterator5Ptr it2 = ms_context->CreateIterator5(
        river, ScType::ConstCommonArc, ScType::Unknown, ScType::ConstPermPosArc, Keynodes::nrel_basin);
    while (it2->Next())
    {
      ScAddr num = it2->Get(2);
      std::string str = CommonUtils::getIdtf(ms_context.get(), num, Keynodes::nrel_main_idtf);
      SC_AGENT_LOG_INFO(str.c_str());
      int n = std::atoi(str.c_str());
      if (number < n)
      {
        number = n;
        riv = river;
      }
    }
  }
  ms_context->GenerateConnector(ScType::ConstPermPosArc, answer, riv);

  ScAddr edgeToAnswer = ms_context->GenerateConnector(ScType::ConstCommonArc, actionNode, answer);
  ms_context->GenerateConnector(ScType::ConstPermPosArc, ScKeynodes::nrel_answer, edgeToAnswer);

  SC_AGENT_LOG_INFO("----------TheBiggestBasinInRegion end----------");
//todo(codegen-removal): replace AgentUtils:: usage
  AgentUtils::finishAgentWork(ms_context.get(), actionNode);
  return action.FinishSuccessfully();
}

ScAddr TheBiggestBasinInRegion::GetActionClass() const
{
//todo(codegen-removal): replace action with your action class
  return ScKeynodes::action;
}

ScAddr TheBiggestBasinInRegion::GetEventSubscriptionElement() const
{
  return Keynodes::question_theBiggestBasinInRegion;
}
}  // namespace RiversModule
