#include "RiversModule.hpp"
namespace RiversModule
{
SC_MODULE_REGISTER(RiversModule)
  ->Agent<TheBiggestBasinInRegion>()
  ->Agent<LongerRiver>()
  ->Agent<LongestInRegion>()
  ->Agent<BiggerBasin>()
  ->Agent<ShorterRiver>();

//todo(codegen-removal): if needed override ScModule::Initialize and move all non-keynodes and non-agents code from previous initialization method
/*
{
  if (!Keynodes::InitGlobal())
  {
    return SC_RESULT_ERROR;
  }

  ScMemoryContext ctx(sc_access_lvl_make_min, "RiversModule");

  //todo(codegen-removal): Use agentContext.SubscribeAgent<TheBiggestBasinInRegion> or UnsubscribeAgent; to register and unregister agent
SC_AGENT_REGISTER(TheBiggestBasinInRegion)
  //todo(codegen-removal): Use agentContext.SubscribeAgent<LongerRiver> or UnsubscribeAgent; to register and unregister agent
SC_AGENT_REGISTER(LongerRiver)
  //todo(codegen-removal): Use agentContext.SubscribeAgent<LongestInRegion> or UnsubscribeAgent; to register and unregister agent
SC_AGENT_REGISTER(LongestInRegion)
  //todo(codegen-removal): Use agentContext.SubscribeAgent<BiggerBasin> or UnsubscribeAgent; to register and unregister agent
SC_AGENT_REGISTER(BiggerBasin)
  //todo(codegen-removal): Use agentContext.SubscribeAgent<ShorterRiver> or UnsubscribeAgent; to register and unregister agent
SC_AGENT_REGISTER(ShorterRiver)

  return SC_RESULT_OK;
}
*/


//todo(codegen-removal): if needed override ScModule::Shutdown and move all non-agents code from previous shutdown method
/*
{
  //todo(codegen-removal): Use agentContext.SubscribeAgent<TheBiggestBasinInRegion> or UnsubscribeAgent; to register and unregister agent
SC_AGENT_UNREGISTER(TheBiggestBasinInRegion)
  //todo(codegen-removal): Use agentContext.SubscribeAgent<LongerRiver> or UnsubscribeAgent; to register and unregister agent
SC_AGENT_UNREGISTER(LongerRiver)
  //todo(codegen-removal): Use agentContext.SubscribeAgent<LongestInRegion> or UnsubscribeAgent; to register and unregister agent
SC_AGENT_UNREGISTER(LongestInRegion)
  //todo(codegen-removal): Use agentContext.SubscribeAgent<BiggerBasin> or UnsubscribeAgent; to register and unregister agent
SC_AGENT_UNREGISTER(BiggerBasin)
  //todo(codegen-removal): Use agentContext.SubscribeAgent<ShorterRiver> or UnsubscribeAgent; to register and unregister agent
SC_AGENT_UNREGISTER(ShorterRiver)
  return SC_RESULT_OK;
}
*/
}  // namespace RiversModule
