#include "sc-agents-common/utils/CommonUtils.hpp"
#include "sc-agents-common/utils/IteratorUtils.hpp"
#include "sc-memory/sc_memory.hpp"
#include <string>
#include <iostream>
#include <vector>

#include "PharmacySearchByCityAndRegionAgent.hpp"
#include "keynodes/keynodes.hpp"

using namespace std;
using namespace utils;

namespace PharmacySearchByCityAndRegionAgentModule
{

ScResult PharmacySearchByCityAndRegionAgent::DoProgram(ScEventAfterGenerateOutgoingArc<ScType::ConstPermPosArc> const & event, ScAction & action)
{
  if (!event.GetArc().IsValid())
    return action.FinishUnsuccessfully();

  SC_AGENT_LOG_INFO("begin");
  ScAddr /*add*/ const actionNode = m_context.GetArcTargetElement(event.GetArc());

  ScAddr pharmacy =
      IteratorUtils::getAnyByOutRelation(&m_context, actionNode, ScKeynodes::rrel_1);

  if (!pharmacy.IsValid())
  {
    SC_AGENT_LOG_ERROR("First parameter isn't valid.");
//todo(codegen-removal): replace AgentUtils:: usage
    //AgentUtils::*/finishAgentWork(&m_context, actionNode, false);
    return action.FinishUnsuccessfully();
  }

  ScAddr /*add*/const answer = /**add point*/m_context.GenerateNode(ScType::ConstNodeStructure);

  ScIterator5Ptr it1 = m_context.CreateIterator5(
      ScType::Unknown, ScType::ConstCommonArc, /*add type*/pharmacy, ScType::ConstPermPosArc, Keynodes::nrel_city);
  ScAddr pharmacy1;
  ScAddr pharmacyResult;
  if (it1->Next())
  {
    pharmacy = it1->Get(0);
    ScIterator5Ptr it2 = m_context.CreateIterator5(
        /*add type*/pharmacy, ScType::ConstCommonArc, ScType::Unknown, ScType::ConstPermPosArc, Keynodes::nrel_region);
    if (it2->Next())
    {
      m_context.GenerateConnector(ScType::ConstPermPosArc, answer, pharmacyResult);
    }
    else
    {
      SC_AGENT_LOG_ERROR("There is no such pharmacy");
    }
  }

  ScAddr edgeToAnswer = m_context.GenerateConnector(ScType::ConstCommonArc, actionNode, answer);
  m_context.GenerateConnector(ScType::ConstPermPosArc, ScKeynodes::nrel_result, edgeToAnswer);

//todo(codegen-removal): replace AgentUtils:: usage
  //AgentUtils::*/finishAgentWork(ms_context.get(), actionNode);
  SC_AGENT_LOG_INFO("end");
  return action.FinishSuccessfully();
}

ScAddr PharmacySearchByCityAndRegionAgent::GetActionClass() const
{
//todo(codegen-removal): replace action with your action class
  SC_AGENT_LOG_ERROR("Get action");
  return Keynodes::action_pharmacyByCityAndRegionSearch;
}

ScAddr PharmacySearchByCityAndRegionAgent::GetEventSubscriptionElement() const
{
  SC_AGENT_LOG_ERROR("Get event");
  return Keynodes::action_pharmacyByCityAndRegionSearch;
}

}  // namespace PharmacySearchByCityAndRegionAgentModule
