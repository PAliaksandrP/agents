#pragma once

#include <sc-memory/sc_agent.hpp>

#include "keynodes/keynodes.hpp"
namespace PharmacySearchByCityAndRegionAgentModule
{

class PharmacySearchByCityAndRegionAgent : public ScAgent<ScEventAfterGenerateOutgoingArc<ScType::ConstPermPosArc>>
{
  public:
  ScAddr GetActionClass() const override;

  ScResult DoProgram(ScEventAfterGenerateOutgoingArc<ScType::ConstPermPosArc> const & event, ScAction & action) override;

  ScAddr GetEventSubscriptionElement() const override;

  };

}  // namespace PharmacySearchByCityAndRegionAgentModule
