#pragma once
#include "sc-memory/sc_memory.hpp"
#include "sc-memory/sc_module.hpp"

#include "keynodes/PharmacyKeynodes.hpp"
#include "agents/PharmacySearchByCityAndRegionAgent.hpp"

namespace PharmacySearchByCityAndRegionAgentModule
{

class PharmacySearchByCityAndRegionAgentModule : public ScModule
{
  // void Initialize(ScMemoryContext * context);
  // void Shutdown(ScMemoryContext * context);
  };
}  // namespace PharmacySearchByCityAndRegionAgentModule
