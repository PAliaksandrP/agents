#pragma once

#include "sc-memory/sc_memory.hpp"
#include "sc-memory/sc_module.hpp"

#include "keynodes/PotteryKeynodes.hpp"
#include "agents/PotteryDate.hpp"

namespace PotteryModule
{

class PotteryModule : public ScModule
{
  // void Initialize(ScMemoryContext * context);
  // void Shutdown(ScMemoryContext * context);
};
}  // namespace PotteryModule
