#pragma once
#include "sc-memory/sc_memory.hpp"
#include "sc-memory/sc_module.hpp"

#include "keynodes/SchoolKeynodes.hpp"
#include "agents/SchoolSearchAgent.hpp"

namespace SchoolSearchAgentModule
{

class SchoolSearchAgentModule : public ScModule
{
  // void Initialize(ScMemoryContext * context);
  // void Shutdown(ScMemoryContext * context);
  };
}  // namespace SchoolSearchAgentModule
